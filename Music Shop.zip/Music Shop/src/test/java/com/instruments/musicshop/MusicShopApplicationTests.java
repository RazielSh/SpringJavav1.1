package com.instruments.musicshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MusicShopApplicationTests {

    @Test
    void contextLoads() {
    }

}
