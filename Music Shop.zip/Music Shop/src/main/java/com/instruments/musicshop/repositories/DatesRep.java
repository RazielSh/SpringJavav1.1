package com.instruments.musicshop.repositories;

import com.instruments.musicshop.model.Dates;
import org.springframework.data.repository.CrudRepository;

public interface DatesRep extends CrudRepository<Dates,Long> {
}
