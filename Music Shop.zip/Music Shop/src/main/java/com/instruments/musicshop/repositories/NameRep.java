package com.instruments.musicshop.repositories;

import com.instruments.musicshop.model.Name;
import org.springframework.data.repository.CrudRepository;

public interface NameRep extends CrudRepository<Name,Long> {
}
