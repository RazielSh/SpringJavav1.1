package com.instruments.musicshop.tools;

import com.instruments.musicshop.model.Instrument;
import com.instruments.musicshop.model.Name;
import com.instruments.musicshop.repositories.DatesRep;
import com.instruments.musicshop.model.Dates;
import com.instruments.musicshop.model.Additional;
import com.instruments.musicshop.repositories.AdditionalRep;
import com.instruments.musicshop.repositories.NameRep;
import com.instruments.musicshop.repositories.InstrumentRep;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

@Component
public class DBInflater implements ApplicationListener<ContextRefreshedEvent> {

    private InstrumentRep instrumentRep;
    private NameRep nameRep;
    private DatesRep datesRep;
    private AdditionalRep additionalRep;

    public DBInflater(InstrumentRep instrumentRep, NameRep nameRep, DatesRep datesRep, AdditionalRep additionalRep) {
        this.instrumentRep = instrumentRep;
        this.nameRep = nameRep;
        this.datesRep = datesRep;
        this.additionalRep = additionalRep;
    }
    @Override
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {
        initData();
    }

    private void initData() {
        Instrument Gibson = new Instrument("Gibson");
        Name LesPaul = new Name("Les Paul");
        Dates When1 = new Dates("1953", "1954-1960, 1964-Present");
        Additional info1 = new Additional("Electric Guitar");

        When1.getAdditional().add(info1);
        info1.getDates().add(When1);
        LesPaul.setInstrument(Gibson);

        instrumentRep.save(Gibson);
        nameRep.save(LesPaul);
        datesRep.save(When1);
        additionalRep.save(info1);

        Instrument GibsonBass = new Instrument("Gibson");
        Name EB3 = new Name("EB-3");
        Dates When2 = new Dates("1961", "1961-1979");
        Additional info2 = new Additional("Bass Guitar");

        When2.getAdditional().add(info1);
        info1.getDates().add(When2);
        EB3.setInstrument(GibsonBass);

        instrumentRep.save(GibsonBass);
        nameRep.save(EB3);
        datesRep.save(When2);
        additionalRep.save(info2);
    }
}


















