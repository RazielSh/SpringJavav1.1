package com.instruments.musicshop.controllers;

import com.instruments.musicshop.model.Additional;
import com.instruments.musicshop.repositories.AdditionalRep;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class AddAdditional {+

    private AdditionalRep additionalRep;
    public AddAdditional(AdditionalRep additionalRep) {
        this.additionalRep = additionalRep;
    }

    @RequestMapping("AddAdditional")
    public String NewPage(AddAdditional additional) {

        return "AddAdditional";
    }
    @RequestMapping(value = "/SAVE2", method = RequestMethod.POST)
    public String SaveAdditional(@ModelAttribute("additional") Additional additional) {
        additionalRep.save(additional);
        return "/Additional";}

}