package com.instruments.musicshop.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import java.util.HashSet;
import java.util.Set;

@Entity
public class Dates {
    @Id
    @GeneratedValue
    private Long Id;
    private String ProductionDate;
    private String ShippmentDate;
    @ManyToMany (mappedBy = "Dates")
    private Set<Additional> Additional = new HashSet<>();

    public Dates()
    {
    }
    public Dates(String productiondate, String shippmentdate) {
        ProductionDate = productiondate;
        ShippmentDate = shippmentdate;
    }
    public Dates(Long id, String productiondate, String shippmentdate, Set<Additional> additional) {
        Id = id;
        ProductionDate = productiondate;
        ShippmentDate = shippmentdate;
        Additional = additional;
    }
    public Long getId() {
        return Id;
    }
    public void setId(Long id) {
        Id = id;
    }

    public String getProductionDate() {
        return ProductionDate;
    }
    public void setProductionDate(String productiondate) { ProductionDate = productiondate; }

    public String getShippmentDate() {
        return ShippmentDate;
    }
    public void setShippmentDate(String shippmentdate) {
        ShippmentDate = shippmentdate;
    }

    public Set<Additional> getAdditional() {
        return Additional;
    }
    public void setAdditional(Set<Additional> additional) {
        Additional = additional;
    }
    @Override
    public String toString() {
        return "Dates{" +
                "Id=" + Id +
                "Production Date=" + ProductionDate + '\'' +
                "Shippment Date=" + ShippmentDate + '\'' +
                "Additional=" + Additional +
                '}';
    }
}

