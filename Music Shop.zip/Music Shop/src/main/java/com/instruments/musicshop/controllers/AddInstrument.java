package com.instruments.musicshop.controllers;

import com.instruments.musicshop.model.Instrument;
import com.instruments.musicshop.repositories.InstrumentRep;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class AddInstrument {

    private InstrumentRep instrumentRep;
    public AddInstrument(InstrumentRep instrumentRep) {
        this.instrumentRep = instrumentRep;
    }

    @RequestMapping("AddInstrument")
    public String NewPage(Model model) {
        Instrument instrument = new Instrument();
        model.addAttribute("AddInstument", instrument);
        return "AddInstrument";
    }
    @RequestMapping(value = "/SAVE3", method = RequestMethod.POST)
    public String SaveInstrument(@ModelAttribute("Instrument") Instrument instrument) {
        instrumentRep.save(instrument);
        return "/Instrument";}
}
