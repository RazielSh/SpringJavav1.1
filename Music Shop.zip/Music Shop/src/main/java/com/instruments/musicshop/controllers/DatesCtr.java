package com.instruments.musicshop.controllers;

import com.instruments.musicshop.repositories.DatesRep;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DatesCtr
{
    private DatesRep DatesRep;
    public DatesCtr(DatesRep datesRep) { this.DatesRep = datesRep; }

    @RequestMapping("Dates")
    public String GetDates(Model model)
    {
        model.addAttribute("Dates", DatesRep.findAll());
        return "Dates";
    }
}