package com.instruments.musicshop.controllers;

import com.instruments.musicshop.model.Name;
import com.instruments.musicshop.repositories.NameRep;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class AddName {

    private NameRep nameRep;
    public AddName(NameRep nameRep) {
        this.nameRep = nameRep;
    }

    @RequestMapping("AddName")
    public String NewPage(Model model) {
        Name name = new Name();
        model.addAttribute("AddName", name);
        return "AddName";
    }
    @RequestMapping(value = "/SAVE4", method = RequestMethod.POST)
    public String SaveName(@ModelAttribute("Name") Name name) {
        nameRep.save(name);
        return "/Name";}
}
