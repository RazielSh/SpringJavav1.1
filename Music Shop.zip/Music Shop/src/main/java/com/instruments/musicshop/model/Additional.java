package com.instruments.musicshop.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import java.util.HashSet;
import java.util.Set;
@Entity
public class Additional {
    @Id
    @GeneratedValue
    private Long Id;
    private String MoreInfo;
    @ManyToMany
    private Set<Dates> Dates =new HashSet<>();

    public Additional() {
    }

    public Additional(String moreinfo) {
        MoreInfo = moreinfo;
    }

    public Additional(Long id, String moreinfo, Set<Dates> dates) {
        Id = id;
        MoreInfo = moreinfo;
        Dates = dates;
    }

    public Long getId() {
        return Id;
    }
    public void setId(Long id) {
        Id = id;
    }

    public String getMoreInfo() {
        return MoreInfo;
    }
    public void setMoreInfo(String moreinfo) {
        MoreInfo = moreinfo;
    }

    public Set<Dates> getDates() {
        return Dates;
    }
    public void setDates(Set<Dates> dates) {
        Dates = dates;
    }

    @Override
    public String toString() {
        return "Additional{" +
                "Id=" + Id +
                ", More Info='" + MoreInfo + '\'' +
                ", Dates=" + Dates +
                '}';
    }
}
