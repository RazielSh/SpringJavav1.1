package com.instruments.musicshop.model;

import javax.persistence.*;

@Entity
public class Name {
    @Id
    @GeneratedValue
    private Long Id;
    private String Name;
    @ManyToOne
    private Instrument Instrument;

    public Name() {
    }

    public Name(String name) {
        Name = name;

    }

    public Name(Long id, String name, Instrument instrument) {
        Id = id;
        Name = name;
        Instrument = instrument;
    }

    public Long getId() {
        return Id;
    }
    public void setId(Long id) {
        Id = id;
    }

    public String getName() {
        return Name;
    }
    public void setMName(String name) {
        Name = name;
    }

    public Instrument getInstrument() {
        return Instrument;
    }
    public void setInstrument(Instrument instrument) {
        Instrument = instrument;
    }

    @Override
    public String toString() {
        return "Name{" +
                "Id=" + Id +
                ", Model Name='" + Name + '\'' +
                ", Instrument=" + Instrument +
                '}';
    }
}
