package com.instruments.musicshop.repositories;

import com.instruments.musicshop.model.Instrument;
import org.springframework.data.repository.CrudRepository;

public interface InstrumentRep extends CrudRepository<Instrument,Long> {
}
