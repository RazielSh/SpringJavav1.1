package com.instruments.musicshop.controllers;

import com.instruments.musicshop.repositories.AdditionalRep;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AdditionalCtr
{
    private AdditionalRep additionalRep;
    public AdditionalCtr(AdditionalRep additionalRep) {
        this.additionalRep = additionalRep;
    }

    @RequestMapping("Additional")
    public String GetAdditional(Model model)
    {
        model.addAttribute("Additional", additionalRep.findAll());
        return "Additional";
    }
}


