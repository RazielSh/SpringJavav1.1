package com.instruments.musicshop.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Instrument {
    @Id
    @GeneratedValue
    private Long Id;
    private String Name;

    public Instrument() {
    }
    public Instrument(String name) { Name = name;
    }
    public Instrument(Long id, String name) {
        Id = id;
        Name = name;
    }
    public Long getId() {
        return Id;
    }
    public void setId(Long id) {
        Id = id;
    }

    public String getName() {
        return Name;
    }
    public void setName(String name) {
        Name = name;
    }

    @Override
    public String toString() {
        return "Instrument{" +
                "Id=" + Id +
                "Name=" + Name + '\'' +
                '}';
    }
}
