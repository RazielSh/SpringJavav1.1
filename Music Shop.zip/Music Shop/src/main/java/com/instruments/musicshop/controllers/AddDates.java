package com.instruments.musicshop.controllers;

import com.instruments.musicshop.model.Dates;
import com.instruments.musicshop.repositories.DatesRep;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class AddDates {

    private DatesRep datesRep;
    public AddDates(DatesRep datesRep) {
        this.datesRep = datesRep;
    }

    @RequestMapping("AddDates")
    public String NewPage(Model model) {
        Dates dates = new Dates();
        model.addAttribute("AddDates", dates);
        return "AddDates";
    }
    @RequestMapping(value = "/SAVE1", method = RequestMethod.POST)
    public String SaveDates(@ModelAttribute("Dates") Dates dates) {
        datesRep.save(dates);
        return "/Dates";}
}
