package com.instruments.musicshop.controllers;

import com.instruments.musicshop.repositories.InstrumentRep;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class InstrumentCtr
{
    private InstrumentRep instrumentRep;
    public InstrumentCtr(InstrumentRep instrumentRep) { this.instrumentRep = instrumentRep; }

    @RequestMapping("Instrument")
    public String GetInstrument(Model model)
    {
        model.addAttribute("Instrument", instrumentRep.findAll());
        return "Instrument";
    }
}