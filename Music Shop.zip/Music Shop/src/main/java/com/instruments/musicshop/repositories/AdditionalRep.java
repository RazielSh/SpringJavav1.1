package com.instruments.musicshop.repositories;

import com.instruments.musicshop.model.Additional;
import org.springframework.data.repository.CrudRepository;

public interface AdditionalRep extends CrudRepository<Additional, Long> {
}
