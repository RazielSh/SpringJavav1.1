package com.instruments.musicshop.controllers;

import com.instruments.musicshop.repositories.NameRep;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class NameCtr
{
    private NameRep nameRep;
    public NameCtr(NameRep nameRep) {
        this.nameRep = nameRep;
    }

    @RequestMapping("Name")
    public String GetName(Model model)
    {
        model.addAttribute("Name", nameRep.findAll());
        return "Name";
    }
}